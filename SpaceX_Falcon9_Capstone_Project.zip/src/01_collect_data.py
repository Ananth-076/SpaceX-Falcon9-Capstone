"""Collect SpaceX launch data from the public API and save a flat CSV."""
from pathlib import Path
import requests
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "data"
OUT.mkdir(exist_ok=True, parents=True)

URL = "https://api.spacexdata.com/v4/launches/query"
payload = {
    "query": {},
    "options": {
        "select": [
            "name", "date_utc", "success", "rocket", "launchpad", "payloads",
            "cores", "flight_number", "details", "links"
        ],
        "pagination": False
    }
}
r = requests.post(URL, json=payload, timeout=60)
r.raise_for_status()
docs = r.json().get("docs", [])
if not docs:
    raise RuntimeError("No launch records returned by SpaceX API.")
launches = pd.json_normalize(docs, sep="_")

# Convert nested core outcomes into launch-level features.
def first_core(value):
    if isinstance(value, list) and value:
        return value[0]
    return {}
launches["core0"] = launches["cores"].apply(first_core)
launches["landing_attempt"] = launches["core0"].apply(
    lambda x: x.get("landing_attempt") if isinstance(x, dict) else None
)
launches["landing_success"] = launches["core0"].apply(
    lambda x: x.get("landing_success") if isinstance(x, dict) else None
)
launches["reused"] = launches["core0"].apply(
    lambda x: x.get("reused") if isinstance(x, dict) else None
)
launches["core_serial"] = launches["core0"].apply(
    lambda x: x.get("core") if isinstance(x, dict) else None
)
launches["date_utc"] = pd.to_datetime(launches["date_utc"], errors="coerce", utc=True)
launches.to_csv(OUT / "spacex_launches_raw.csv", index=False)
print(f"Saved {len(launches)} launch records to {OUT / 'spacex_launches_raw.csv'}")
print("Next: run src/02_analysis_and_models.py")
