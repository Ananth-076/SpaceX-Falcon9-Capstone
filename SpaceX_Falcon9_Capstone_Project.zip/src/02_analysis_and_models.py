"""Clean SpaceX launch data, perform EDA/SQL, build a Folium map and evaluate classifiers."""
from pathlib import Path
import ast, json, warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sqlalchemy import create_engine
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, classification_report
from sklearn.dummy import DummyClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
import folium

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"; OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True, parents=True)
raw_path = DATA / "spacex_launches_raw.csv"
if not raw_path.exists():
    raise FileNotFoundError("Run python src/01_collect_data.py first.")
df = pd.read_csv(raw_path)
df["date_utc"] = pd.to_datetime(df["date_utc"], errors="coerce", utc=True)
for col in ["success", "landing_attempt", "landing_success", "reused"]:
    if col in df:
        df[col] = df[col].map(lambda v: v if isinstance(v, (bool, np.bool_)) else
                              (True if str(v).lower()=="true" else False if str(v).lower()=="false" else np.nan))
df["launch_year"] = df["date_utc"].dt.year
df["launch_month"] = df["date_utc"].dt.month
# Landing success target: only attempted landings with a known outcome.
df = df[df["landing_attempt"] == True].copy()
df = df[df["landing_success"].notna()].copy()
df["target"] = df["landing_success"].astype(int)
if len(df) < 20 or df["target"].nunique() < 2:
    raise RuntimeError("Not enough valid landing-attempt records/classes to train. Inspect API schema and exported CSV.")

# Flatten a few feature columns that are available at launch time.
def parse_list(x):
    try:
        v = ast.literal_eval(x) if isinstance(x, str) else x
        return v if isinstance(v, list) else []
    except Exception:
        return []
for col in ["payloads", "cores"]:
    if col in df:
        df[col] = df[col].apply(parse_list)
df["payload_count"] = df["payloads"].apply(len)
df["core_reused"] = df["reused"].map({True:1, False:0})
df["launch_success"] = df["success"].map({True:1, False:0})
# Launchpad IDs are categorical identifiers; these are pre-launch fields.
feature_candidates = ["launchpad", "rocket", "flight_number", "launch_year", "launch_month",
                      "payload_count", "core_reused"]
features = [c for c in feature_candidates if c in df.columns and df[c].notna().any()]
X = df[features].copy()
y = df["target"]
cat = [c for c in X.columns if X[c].dtype == "object"]
num = [c for c in X.columns if c not in cat]
pre = ColumnTransformer([
    ("num", Pipeline([("impute", SimpleImputer(strategy="median")), ("scale", StandardScaler())]), num),
    ("cat", Pipeline([("impute", SimpleImputer(strategy="most_frequent")),
                      ("onehot", OneHotEncoder(handle_unknown="ignore"))]), cat)
])
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)
models = {
    "Baseline": DummyClassifier(strategy="most_frequent"),
    "Logistic Regression": LogisticRegression(max_iter=2000, class_weight="balanced"),
    "Decision Tree": DecisionTreeClassifier(max_depth=5, random_state=42, class_weight="balanced"),
    "Random Forest": RandomForestClassifier(n_estimators=300, max_depth=6, random_state=42, class_weight="balanced")
}
rows=[]; fitted={}
for name, model in models.items():
    pipe = Pipeline([("prep", pre), ("model", model)])
    pipe.fit(X_train, y_train)
    pred = pipe.predict(X_test)
    rows.append({"model":name, "accuracy":accuracy_score(y_test,pred),
                 "precision":precision_score(y_test,pred,zero_division=0),
                 "recall":recall_score(y_test,pred,zero_division=0),
                 "f1":f1_score(y_test,pred,zero_division=0)})
    fitted[name]=(pipe,pred)
metrics = pd.DataFrame(rows).sort_values("f1", ascending=False)
metrics.to_csv(OUT/"model_metrics.csv",index=False)
metrics.to_string(index=False)
best_name = metrics.iloc[0]["model"]
best_pipe, best_pred = fitted[best_name]
pd.DataFrame(confusion_matrix(y_test,best_pred), index=["Actual 0","Actual 1"],
             columns=["Predicted 0","Predicted 1"]).to_csv(OUT/"confusion_matrix.csv")
(OUT/"classification_report.txt").write_text(
    f"Best by F1: {best_name}\nFeatures: {features}\n\n"+
    classification_report(y_test,best_pred,zero_division=0))

# EDA charts
yearly = df.groupby("launch_year", dropna=True)["target"].agg(["mean","count"]).reset_index()
yearly.rename(columns={"mean":"landing_success_rate","count":"attempts"},inplace=True)
yearly.to_csv(OUT/"yearly_landing_success.csv",index=False)
plt.figure(figsize=(9,5))
plt.plot(yearly["launch_year"], yearly["landing_success_rate"], marker="o")
plt.title("Landing Success Rate by Year"); plt.xlabel("Launch year"); plt.ylabel("Success rate")
plt.ylim(0,1); plt.grid(alpha=.25); plt.tight_layout(); plt.savefig(OUT/"landing_success_by_year.png",dpi=160); plt.close()

by_site = df.groupby("launchpad")["target"].agg(["mean","count"]).reset_index().sort_values("mean",ascending=False)
by_site.to_csv(OUT/"landing_success_by_site.csv",index=False)
plt.figure(figsize=(10,5))
plt.bar(by_site["launchpad"].astype(str),by_site["mean"])
plt.title("Landing Success Rate by Launch Site"); plt.xlabel("Launch site ID"); plt.ylabel("Success rate")
plt.xticks(rotation=30,ha="right"); plt.ylim(0,1); plt.tight_layout(); plt.savefig(OUT/"landing_success_by_site.png",dpi=160); plt.close()

# SQL analysis in SQLite; exported query outputs and query text are auditable.
engine = create_engine(f"sqlite:///{OUT/'spacex_eda.sqlite'}")
sql_df = df.copy()
sql_df["date_utc"] = sql_df["date_utc"].astype(str)
sql_df.to_sql("launches", engine, if_exists="replace", index=False)
queries = {
"success_by_year": """SELECT launch_year, COUNT(*) AS landing_attempts,
 ROUND(AVG(target)*100, 1) AS success_pct FROM launches
 GROUP BY launch_year ORDER BY launch_year""",
"success_by_site": """SELECT launchpad, COUNT(*) AS attempts,
 ROUND(AVG(target)*100, 1) AS success_pct FROM launches
 GROUP BY launchpad ORDER BY success_pct DESC""",
"reuse_comparison": """SELECT core_reused, COUNT(*) AS attempts,
 ROUND(AVG(target)*100, 1) AS success_pct FROM launches
 GROUP BY core_reused ORDER BY core_reused"""
}
sql_summaries=[]
for name, query in queries.items():
    result=pd.read_sql_query(query,engine)
    result.to_csv(OUT/f"sql_{name}.csv",index=False)
    sql_summaries.append(f"-- {name}\n{query}\n\n{result.to_string(index=False)}\n")
(OUT/"sql_queries_and_results.txt").write_text("\n".join(sql_summaries))

# Folium map: resolve launchpad IDs to coordinates through the public launchpads API.
import requests
try:
    pad_data = requests.get("https://api.spacexdata.com/v4/launchpads",timeout=30).json()
    pads = {p.get("id"):p for p in pad_data}
    m = folium.Map(location=[28.5,-80.6], zoom_start=4, tiles="OpenStreetMap")
    for pad_id, stats in df.groupby("launchpad")["target"].agg(["mean","count"]).iterrows():
        p=pads.get(pad_id,{})
        lat=p.get("latitude"); lon=p.get("longitude")
        if lat is not None and lon is not None:
            folium.CircleMarker([lat,lon],radius=6+min(int(stats["count"]),20)/2,
                popup=f'{p.get("name",pad_id)} | attempts={int(stats["count"])} | success={stats["mean"]:.1%}',
                tooltip=p.get("name","Launch site"),
                color="#167D9A",fill=True,fill_opacity=.7).add_to(m)
    m.save(OUT/"launch_sites_map.html")
except Exception as e:
    warnings.warn(f"Map generation skipped: {e}")

print("\nDATA PROFILE")
print(f"Landing attempts with known outcomes: {len(df)}")
print(f"Features used: {features}")
print("\nMODEL METRICS (computed from current API response)")
print(metrics.to_string(index=False))
print(f"\nBest model by F1: {best_name}")
print("\nGenerated outputs in:", OUT)
