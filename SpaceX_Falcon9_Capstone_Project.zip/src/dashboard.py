"""Interactive Plotly Dash dashboard based on generated analysis outputs."""
from pathlib import Path
import pandas as pd
from dash import Dash, dcc, html, Input, Output
import plotly.express as px

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/"outputs"
year_path=OUT/"yearly_landing_success.csv"
site_path=OUT/"landing_success_by_site.csv"
if not year_path.exists() or not site_path.exists():
    raise FileNotFoundError("Run src/02_analysis_and_models.py before launching the dashboard.")
year=pd.read_csv(year_path)
site=pd.read_csv(site_path)
app=Dash(__name__)
app.layout=html.Div([
    html.H1("SpaceX Landing Success Explorer"),
    html.P("Explore landing outcomes from the public SpaceX API. Figures update from the generated analysis files."),
    html.Label("Choose a view"),
    dcc.Dropdown(id="view", options=[
        {"label":"Success rate by year","value":"year"},
        {"label":"Success rate by launch site","value":"site"}],
        value="year", clearable=False, style={"maxWidth":"460px"}),
    dcc.Graph(id="chart"),
    html.Div(id="summary")
], style={"fontFamily":"Arial","maxWidth":"1100px","margin":"30px auto"})
@app.callback(Output("chart","figure"),Output("summary","children"),Input("view","value"))
def update(view):
    if view=="year":
        fig=px.line(year,x="launch_year",y="landing_success_rate",markers=True,
                    hover_data=["attempts"],title="Landing success rate by year")
        summary=f"{int(year['attempts'].sum())} landing attempts with known outcomes in the analyzed dataset."
    else:
        fig=px.bar(site,x="launchpad",y="mean",hover_data=["count"],
                   title="Landing success rate by launch site",labels={"mean":"success rate","launchpad":"launch site"})
        summary=f"{len(site)} launch site identifiers represented in the analyzed landing attempts."
    fig.update_yaxes(tickformat=".0%",range=[0,1])
    return fig,summary
if __name__=="__main__":
    app.run(debug=False)
