# SpaceX Falcon 9 First-Stage Landing Prediction — Reproducible Capstone

This repository-style project is a reproducible starter submission for the IBM Data Science Capstone.
It includes runnable scripts/notebooks for collection, wrangling, EDA, SQL, Folium mapping, Plotly Dash,
and classification. The code downloads the public SpaceX API data when run; **results are not claimed
to have been executed in this chat**. Run the workflow and use the generated outputs/screenshots in your
final submission.

## Files
- `spacex_capstone.ipynb` — end-to-end notebook
- `src/01_collect_data.py` — API collection and CSV export
- `src/02_analysis_and_models.py` — cleaning, EDA, SQL, evaluation, plots, Folium map
- `src/dashboard.py` — Plotly Dash app
- `requirements.txt` — dependencies
- `outputs/` — generated files will be saved here after execution

## Run
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python src/01_collect_data.py
python src/02_analysis_and_models.py
python src/dashboard.py
```
Open the printed `outputs/launch_sites_map.html`. The dashboard runs locally (usually http://127.0.0.1:8050).

## Publish to your own GitHub
Create a repository under your own GitHub account, upload all files, and place that repository URL on the PDF
and submission form. Do not submit a reference repository as if it were your own.

## Methodology
Data is retrieved from the public SpaceX API. The analysis defines landing success from the booster landing
outcome (`land_success` when available, otherwise the dataset's landing outcome fields). The model uses
pre-launch features only where possible and reports metrics computed from the fetched data. API schemas may
evolve; inspect the exported CSV and adjust field names if needed.
